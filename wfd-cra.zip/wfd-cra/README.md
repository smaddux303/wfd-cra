# Westminster Fire Department — Community Risk Assessment
### Interactive CRA · 2024–2028 Accreditation Cycle

This repository hosts the data, code, and documentation for the Westminster Fire Department's interactive Community Risk Assessment, built for the 2024–2028 CFAI accreditation cycle.

The CRA is published as a GitHub Pages website at:
**[https://westminster-fire.github.io/wfd-cra](https://westminster-fire.github.io/wfd-cra)**

---

## Repository Structure

```
wfd-cra/
├── index.html                  ← Main CRA webpage (GitHub Pages entry point)
├── assets/
│   └── css/
│       └── style.css           ← Westminster brand styles
├── data/
│   ├── raw/                    ← Original downloads from Census, unmodified
│   │   ├── B17001_poverty_raw.csv
│   │   ├── B27001_insurance_raw.csv
│   │   ├── B01001_age_raw.csv
│   │   └── B01003_population_raw.csv
│   └── clean/                  ← Cleaned, analysis-ready files (Datawrapper sources)
│       ├── westminster_poverty.csv
│       ├── westminster_insurance.csv
│       ├── westminster_age_65plus.csv
│       ├── westminster_population_density.csv
│       ├── westminster_stations.csv
│       └── westminster_apparatus.csv
├── maps/
│   └── westminster_districts.geojson   ← Fire district boundaries (if obtained)
├── docs/
│   ├── DATA_SOURCES.md         ← Where every data point comes from
│   ├── UPDATE_GUIDE.md         ← How to update data each cycle
│   └── EMBED_CODES.md          ← Datawrapper & Power BI embed URLs
└── README.md                   ← This file
```

---

## Data Sources

| File | Source | Table | Last Updated |
|------|--------|-------|-------------|
| westminster_poverty.csv | U.S. Census ACS 5-Year | B17001 | 2023 |
| westminster_insurance.csv | U.S. Census ACS 5-Year | B27001 | 2023 |
| westminster_age_65plus.csv | U.S. Census ACS 5-Year | B01001 | 2023 |
| westminster_population_density.csv | U.S. Census ACS 5-Year | B01003 | 2023 |
| westminster_stations.csv | Westminster Fire Dept. | Internal | 2024 |
| westminster_apparatus.csv | Westminster Fire Dept. | Internal | 2024 |

---

## Embedded Content

| Section | Tool | Type |
|---------|------|------|
| At-a-glance KPIs | Power BI | Embed |
| Poverty rate map | Datawrapper | Choropleth |
| Uninsured rate map | Datawrapper | Choropleth |
| Population 65+ map | Datawrapper | Choropleth |
| Population density map | Datawrapper | Choropleth |
| Medical facilities map | Datawrapper | Symbol map |
| Vulnerability dashboard | Power BI | Embed |
| Risk score matrix | Power BI | Embed |

---

## How to Update for the Next Accreditation Cycle

See [docs/UPDATE_GUIDE.md](docs/UPDATE_GUIDE.md) for step-by-step instructions.

---

## Key Contributors

- **Project lead:** Westminster Fire Department
- **GIS support:** Jamie Boelstler
- **Data period:** 2019–2023
- **Accreditation body:** CFAI / CPSE

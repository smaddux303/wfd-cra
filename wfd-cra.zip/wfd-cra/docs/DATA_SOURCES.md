# Data Sources

All data used in the Westminster Fire Department CRA is documented here.

---

## Census Data (ACS 5-Year Estimates, 2019–2023)

### Poverty Rate — `westminster_poverty.csv`
- **Table:** B17001 — Poverty Status in the Past 12 Months by Sex by Age
- **Derived column:** Poverty_Rate = (B17001_002E / B17001_001E) × 100
- **URL:** https://data.census.gov/table/ACSDT5Y2023.B17001

### Health Insurance — `westminster_insurance.csv`
- **Table:** B27001 — Health Insurance Coverage Status by Sex by Age
- **Derived column:** Uninsured_Rate = (total uninsured / total pop) × 100
- **URL:** https://data.census.gov/table/ACSDT5Y2023.B27001

### Population Age 65+ — `westminster_age_65plus.csv`
- **Table:** B01001 — Sex by Age
- **Derived column:** Pct_65plus = (pop 65+ / total pop) × 100
- **URL:** https://data.census.gov/table/ACSDT5Y2023.B01001

### Population Density — `westminster_population_density.csv`
- **Table:** B01003 — Total Population
- **Derived column:** Density = (total pop / tract area in sq mi)
- **URL:** https://data.census.gov/table/ACSDT5Y2023.B01003

---

## Internal WFD Data

### Stations — `westminster_stations.csv`
- **Source:** Westminster Fire Department, Administrative Records

### Apparatus — `westminster_apparatus.csv`
- **Source:** Westminster Fire Department, Fleet Records

# Embed Codes & URLs

Update this file whenever a Datawrapper chart or Power BI report is republished.

---

## Datawrapper Maps

| Map | Datawrapper URL | Section |
|-----|----------------|---------|
| Poverty rate | https://datawrapper.dwcdn.net/XXXXX/1/ | Demographics |
| Uninsured rate | https://datawrapper.dwcdn.net/XXXXX/1/ | Demographics |
| Population 65+ | https://datawrapper.dwcdn.net/XXXXX/1/ | Demographics |
| Population density | https://datawrapper.dwcdn.net/XXXXX/1/ | Community characteristics |
| Medical facilities | https://datawrapper.dwcdn.net/XXXXX/1/ | Community characteristics |

## Power BI Reports

| Report | Embed URL | Section |
|--------|-----------|---------|
| At-a-glance KPIs | https://app.powerbigov.us/view?r=XXXXX | Opening |
| Vulnerability dashboard | https://app.powerbigov.us/view?r=XXXXX | Demographics |
| Risk score matrix | https://app.powerbigov.us/view?r=XXXXX | Risk assessment |

## GitHub Raw Data URLs (paste into Datawrapper)

```
https://raw.githubusercontent.com/YOUR-USERNAME/wfd-cra/main/data/clean/westminster_poverty.csv
https://raw.githubusercontent.com/YOUR-USERNAME/wfd-cra/main/data/clean/westminster_insurance.csv
https://raw.githubusercontent.com/YOUR-USERNAME/wfd-cra/main/data/clean/westminster_age_65plus.csv
https://raw.githubusercontent.com/YOUR-USERNAME/wfd-cra/main/data/clean/westminster_population_density.csv
```

# CRA Update Guide

## Annual update checklist

- [ ] New ACS 5-year data downloaded and cleaned
- [ ] westminster_poverty.csv updated
- [ ] westminster_insurance.csv updated
- [ ] westminster_age_65plus.csv updated
- [ ] westminster_population_density.csv updated
- [ ] westminster_stations.csv reviewed
- [ ] westminster_apparatus.csv reviewed
- [ ] Power BI report refreshed and republished
- [ ] README.md "Last Updated" dates updated
- [ ] GitHub push confirmed
- [ ] Datawrapper maps verified
- [ ] Power BI embeds verified

## Step 1 — Download new Census data
1. Go to data.census.gov
2. Download tables B17001, B27001, B01001, B01003
3. Filter to Colorado / Adams + Jefferson counties / Census Tracts
4. Save to /data/raw/

## Step 2 — Clean in Excel
1. Keep GEO_ID, NAME, and relevant columns
2. Calculate derived columns (rates, percentages)
3. Filter to Westminster tracts
4. Save to /data/clean/ (overwrite existing)

## Step 3 — Push to GitHub
```
git add data/clean/
git commit -m "Update Census data to [YEAR] ACS 5-Year Estimates"
git push
```
Datawrapper maps update automatically within minutes.

## Step 4 — Refresh Power BI
1. Open WFD CRA Power BI file
2. Home → Refresh
3. Republish to Power BI Service
